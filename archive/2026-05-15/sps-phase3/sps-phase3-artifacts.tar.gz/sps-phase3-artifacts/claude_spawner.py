#!/usr/bin/env python3
"""
SPS Phase 3 — claude-binary spawn wrapper (subscription-only).

Inputs (JSON on stdin or argv[1] file):
  next_task_spec  — the dict SPS posted back via slot-manager /release.

Behaviour:
  * Reads spec.id, spec.title, spec.target_bucket, spec.prompt_material.
  * Constructs a SAFE acknowledgment prompt (DO NOT execute the work — just
    confirm readiness, list which must-read-first files are readable). This
    keeps the first real spawn idempotent and short.
  * Invokes the local `claude` binary via `claude -p ... --output-format json
    --max-turns 1 --permission-mode plan`. `--permission-mode plan` puts
    Claude in read-only/plan mode so no edits or shell calls happen during
    the spawn-proof. Subscription auth is used because ANTHROPIC_API_KEY is
    NOT set in env (verified before spawn).
  * Captures: pid, claude version, session_id, model, exit code, duration_ms,
    stderr/stdout heads.
  * On non-zero exit, posts /completion outcome=failed to SPS so its retry
    machinery kicks in (Phase 2 logic).
  * On zero exit, posts /completion outcome=done. Cascades next ready node.

Subscription guard: refuses to run if ANTHROPIC_API_KEY is set. Per
agent-memory/feedback_no_api_key_billing.md the only allowed billing path
is the Max-20x subscription via the claude binary.
"""
from __future__ import annotations
import json
import os
import shlex
import subprocess
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path


SPS_BASE_URL_DEFAULT = "http://10.43.81.39:8080"


def err(msg: str) -> None:
    print(f"[claude-spawner] {msg}", file=sys.stderr, flush=True)


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def subscription_guard() -> None:
    if os.environ.get("ANTHROPIC_API_KEY"):
        err("ABORT: ANTHROPIC_API_KEY is set — refusing per zero-dollar rule.")
        sys.exit(2)


def claude_version() -> str:
    try:
        out = subprocess.check_output(["claude", "--version"], text=True, timeout=10)
        return out.strip().splitlines()[0]
    except Exception as e:
        return f"<error:{e}>"


def build_prompt(spec: dict) -> str:
    nid    = spec.get("id", "<unknown>")
    title  = spec.get("title", "<no title>")
    bucket = spec.get("target_bucket") or spec.get("resolved_bucket") or "<no bucket>"
    pm     = spec.get("prompt_material", {}) or {}
    refs   = pm.get("must_read_first") or []
    scope  = pm.get("scope_tag") or spec.get("scope_tag") or "?"
    item   = pm.get("item_code") or spec.get("item_code") or "?"

    refs_block = "\n".join(f"- {r}" for r in refs) if refs else "(none provided)"

    return (
        "You are spawned by the SPS Phase 3 first-real-spawn test on stolution K3s.\n"
        "This is a SPAWN-PROOF run. DO NOT begin executing the backlog work.\n"
        "Confirm readiness only.\n"
        "\n"
        f"Task spec:\n"
        f"  id          : {nid}\n"
        f"  item_code   : {item}\n"
        f"  scope_tag   : {scope}\n"
        f"  bucket      : {bucket}\n"
        f"  title       : {title}\n"
        f"\n"
        f"Must-read-first refs (do not actually read them yet — just acknowledge):\n"
        f"{refs_block}\n"
        "\n"
        "Reply with ONE compact line of JSON, no prose, in this shape:\n"
        '  {"ack": true, "task_id": "<the id above>", "ready": true, "model": "<your model>"}\n'
    )


def spawn_claude(prompt: str, timeout_s: int = 60) -> dict:
    """Run `claude -p` in plan mode with the given prompt. Return a record."""
    started_ms = int(time.time() * 1000)
    cmd = [
        "claude", "-p", prompt,
        "--output-format", "json",
        "--max-turns", "1",
        "--permission-mode", "plan",
    ]
    err(f"spawning: {' '.join(shlex.quote(c) for c in cmd[:5])} ...")
    try:
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env={**os.environ, "PYTHONUNBUFFERED": "1"},
        )
        pid = proc.pid
        err(f"spawned PID={pid}")
        try:
            stdout, stderr = proc.communicate(timeout=timeout_s)
            rc = proc.returncode
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate()
            rc = -1
            err("TIMEOUT — process killed")
    except FileNotFoundError as e:
        return {
            "ok":          False,
            "error":       f"claude binary not found: {e}",
            "pid":         None,
            "rc":          None,
            "duration_ms": int(time.time() * 1000) - started_ms,
        }
    duration_ms = int(time.time() * 1000) - started_ms

    # Parse session_id from claude --output-format json (stdout)
    session_id = None
    model      = None
    parsed     = None
    if stdout:
        try:
            parsed = json.loads(stdout)
            session_id = parsed.get("session_id") or parsed.get("conversation_id")
            model      = parsed.get("model")
        except Exception as e:
            err(f"could not parse stdout JSON: {e}")

    return {
        "ok":          rc == 0,
        "pid":         pid,
        "rc":          rc,
        "duration_ms": duration_ms,
        "session_id":  session_id,
        "model":       model,
        "stdout_head": (stdout or "")[:2000],
        "stderr_head": (stderr or "")[:2000],
        "parsed":      parsed,
    }


def post_completion(sps_url: str, node_id: str, bucket: str, outcome: str,
                    detail: str | None = None) -> dict | None:
    body = json.dumps({
        "node_id":        node_id,
        "bucket":         bucket,
        "outcome":        outcome,
        "outcome_detail": detail,
    }).encode("utf-8")
    req = urllib.request.Request(
        f"{sps_url}/completion", data=body,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        err(f"post_completion failed: {e}")
        return None


def main() -> int:
    subscription_guard()

    if len(sys.argv) > 1 and sys.argv[1] != "-":
        path = sys.argv[1]
        spec = json.loads(Path(path).read_text(encoding="utf-8"))
    else:
        spec = json.load(sys.stdin)

    # Spec coming from slot-manager /release wraps the SPS spec under
    # next_task_spec; spec coming from SPS /spawn directly is flat.
    if isinstance(spec, dict) and "next_task_spec" in spec:
        spec = spec.get("next_task_spec") or {}

    if not isinstance(spec, dict) or not spec.get("id"):
        err("ABORT: spec missing 'id' — nothing to spawn")
        return 3

    nid    = spec["id"]
    bucket = spec.get("target_bucket") or spec.get("resolved_bucket") or "stolution-claude"

    print(json.dumps({
        "phase":       "pre-spawn",
        "ts":          utcnow_iso(),
        "claude":      claude_version(),
        "subscription_only": True,
        "task_id":     nid,
        "title":       spec.get("title"),
        "bucket":      bucket,
    }, indent=2))

    prompt = build_prompt(spec)
    record = spawn_claude(prompt, timeout_s=60)

    print(json.dumps({
        "phase":       "post-spawn",
        "ts":          utcnow_iso(),
        "task_id":     nid,
        "result":      record,
    }, indent=2, default=str))

    # Spawn-proof only: do NOT post /completion automatically. The orchestrator
    # script that called us decides whether to mark done/partial/failed/cancelled
    # or perform a manual rollback on the spawn_attempts/assignments rows.
    return 0 if record.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
