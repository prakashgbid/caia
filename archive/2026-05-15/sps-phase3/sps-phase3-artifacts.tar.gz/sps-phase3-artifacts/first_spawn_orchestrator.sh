#!/usr/bin/env bash
# SPS Phase 3 — first real end-to-end spawn orchestration.
#
# 1. claim a stolution slot from slot-manager (via kubectl port-forward)
# 2. release the slot — triggers SPS /spawn — yields next_task_spec
# 3. pipe spec into claude_spawner.py — runs the claude binary on Mac
# 4. emit a transcript JSON the memo can quote from
#
# Pre-reqs:
#   * `claude` on PATH (subscription-only auth — ANTHROPIC_API_KEY must be unset)
#   * `kubectl` configured for stolution K3s (the user's Mac, via SSH context
#     OR cluster ClusterIP forwarded over the stolution-remote MCP). For this
#     run we expose slot-manager via kubectl port-forward.
#   * Python 3 available.
#
# Idempotent: each run claims a fresh slot. Slot/task IDs are surfaced in the
# transcript so post-run cleanup can reset state in SQLite if needed.

set -uo pipefail

ART_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$ART_DIR/transcripts"
mkdir -p "$LOG_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
TRANSCRIPT="$LOG_DIR/first-spawn-${STAMP}.json"

SM_URL="${SM_URL:-http://127.0.0.1:8181}"
SPS_URL="${SPS_URL:-http://127.0.0.1:8180}"
BUCKET="${BUCKET:-stolution}"

emit() { python3 -c "import json,sys; print(json.dumps(json.loads(sys.argv[1]), indent=2))" "$1" 2>/dev/null || echo "$1"; }

echo "=== SPS Phase 3 — first-spawn orchestrator (transcript=$TRANSCRIPT) ==="
echo "SM=$SM_URL  SPS=$SPS_URL  BUCKET=$BUCKET"

# 0) Health check
echo "--- 0) reachability ---"
curl -sS --max-time 5 "$SM_URL/health"  || { echo "slot-manager unreachable"; exit 10; }
echo
curl -sS --max-time 5 "$SPS_URL/health" | python3 -m json.tool || { echo "sps unreachable"; exit 11; }

# 1) Claim a slot
echo "--- 1) claim slot in bucket=$BUCKET ---"
CLAIM=$(curl -sS --max-time 10 -X POST "$SM_URL/claim" \
    -H "Content-Type: application/json" \
    -d "{\"bucket\":\"$BUCKET\",\"task_id\":\"phase3-firstspawn-$STAMP\"}")
echo "$CLAIM" | python3 -m json.tool
SLOT_ID=$(echo "$CLAIM" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("slot_id",""))')
TASK_ID=$(echo "$CLAIM" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("task_id",""))')
[ -z "$SLOT_ID" ] && { echo "claim failed — no slot_id"; exit 12; }

# 2) Release — triggers SPS /spawn
echo "--- 2) release slot=$SLOT_ID task=$TASK_ID ---"
RELEASE=$(curl -sS --max-time 10 -X POST "$SM_URL/release" \
    -H "Content-Type: application/json" \
    -d "{\"slot_id\":\"$SLOT_ID\",\"task_id\":\"$TASK_ID\",\"exit_status\":0}")
echo "$RELEASE" | python3 -m json.tool
SPEC=$(echo "$RELEASE" | python3 -c 'import json,sys; d=json.load(sys.stdin); print(json.dumps(d.get("next_task_spec") or {}))')
NODE_ID=$(echo "$SPEC" | python3 -c 'import json,sys; print((json.load(sys.stdin) or {}).get("id",""))')
RES_BUCKET=$(echo "$SPEC" | python3 -c 'import json,sys; print((json.load(sys.stdin) or {}).get("resolved_bucket","stolution-claude"))')

if [ -z "$NODE_ID" ]; then
    echo "ABORT — release returned no next_task_spec.id; nothing to spawn"
    echo "$SPEC"
    exit 13
fi

echo "--- 3) spawn claude (subscription-only) for node=$NODE_ID ---"
echo "$SPEC" > "$LOG_DIR/spec-${STAMP}.json"

# 3) Run wrapper
SPAWN_OUT="$LOG_DIR/spawn-${STAMP}.json"
SPS_URL="$SPS_URL" python3 "$ART_DIR/claude_spawner.py" "$LOG_DIR/spec-${STAMP}.json" 2>&1 | tee "$SPAWN_OUT"
SPAWN_RC=${PIPESTATUS[0]}
echo "claude_spawner rc=$SPAWN_RC"

# 4) Emit transcript
python3 - "$STAMP" "$CLAIM" "$RELEASE" "$NODE_ID" "$RES_BUCKET" "$SPAWN_OUT" "$SPAWN_RC" "$TRANSCRIPT" <<'PY'
import json, sys, pathlib
stamp, claim, release, node_id, res_bucket, spawn_path, rc, transcript = sys.argv[1:9]
spawn_text = pathlib.Path(spawn_path).read_text(encoding="utf-8")
out = {
    "stamp":         stamp,
    "node_id":       node_id,
    "resolved_bucket": res_bucket,
    "claim":         json.loads(claim),
    "release":       json.loads(release),
    "spawn_rc":      int(rc),
    "spawn_log":     spawn_text,
}
pathlib.Path(transcript).write_text(json.dumps(out, indent=2), encoding="utf-8")
print(f"=== transcript saved: {transcript} ===")
PY

echo "--- DONE — exit code reflects spawn rc ($SPAWN_RC) ---"
exit "$SPAWN_RC"
