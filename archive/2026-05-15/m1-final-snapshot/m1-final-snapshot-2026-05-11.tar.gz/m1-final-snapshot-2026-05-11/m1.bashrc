# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
rg='/opt/homebrew/lib/node_modules/\@anthropic-ai/claude-code/vendor/ripgrep/arm64-darwin/rg'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
source ~/.claude/max_performance.sh
# Speed Aliases
..='cd ..'
...='cd ../..'
batch='~/.claude/parallel_executor.sh batch'
c=clear
g=git
gaa='git add -A'
gb='git branch'
gc='git commit -m'
gca='git commit -am'
gco='git checkout'
gd='git diff'
gp='git push'
gpu='git pull'
gs='git status'
h=history
l='ls -la'
pbuild='make -j50'
pp='~/.claude/parallel_executor.sh'
ptest='pytest -n auto'
q=exit
r='source ~/.bashrc'
run-help=man
which-command=whence
qc () {
	git add -A && git commit -m "$1" && git push
}
mkcd () {
	mkdir -p "$1" && cd "$1"
}
update_all () {
	source ~/.claude/batch_templates.sh && update_all_repos
}
test_all () {
	source ~/.claude/batch_templates.sh && test_all
}
build_all () {
	source ~/.claude/batch_templates.sh && build_all
}
export PATH="/Users/MAC/Documents/projects/caia/bin:$PATH"

# 🔍 ENHANCED VERBOSE LOGGING WITH TOOL ATTRIBUTION (PERMANENT)
# Added by CC on 2025-08-30 for complete operation tracking
export CC_VERBOSE_LOGGING=true
export CC_LOG_LEVEL=MICRO
export CC_ATTRIBUTION_TRACKING=true
export ENHANCED_LOGGER_PATH="$HOME/.claude/enhanced_verbose_logger.py"

# Verbose logging functions
cc_log() {
    python3 "$ENHANCED_LOGGER_PATH" log "$@" 2>/dev/null
}

# Monitor tool usage
cc_monitor() {
    python3 "$HOME/.claude/cc_attribution_monitor.py"
}

# Generate session summary  
cc_summary() {
    python3 "$ENHANCED_LOGGER_PATH" summary
}

# Quick aliases
alias ccl='cc_log'
alias ccmon='cc_monitor'
alias ccsum='cc_summary'

# Silent activation indicator
[ -n "$CC_VERBOSE_LOGGING" ] && echo "🔍 CC Verbose Logging Active" >&2

# CKS/CLS Autonomous System - Moved to Claude Code hooks
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'

alias claude-mem='bun "/Users/MAC/.claude/everything-claude-code/scripts/worker-service.cjs"'
