# Basic PATH configuration
export PATH="$HOME/bin:$HOME/.claude/bin:$PATH"
export PATH="/Users/MAC/Documents/projects/caia/bin:$PATH"

# Essential environment variables (silent)
export CC_VERBOSE_LOGGING=true
export CC_LOG_LEVEL=MICRO
export CC_ATTRIBUTION_TRACKING=true
export ENHANCED_LOGGER_PATH="$HOME/.claude/enhanced_verbose_logger.py"
export PROMPT_LOGGER_PATH="$HOME/.claude/prompt_choice_logger.py"
export PROMPT_LOG_DIR="$HOME/Documents/projects/caia/knowledge-system/logs/prompts"
export UNIFIED_DB_PATH="$HOME/Documents/projects/caia/knowledge-system/data/unified_ai.db"
export DB_LOGGER_PATH="$HOME/.claude/db_logger_integration.py"
export USE_DATABASE_LOGGING=true

# Load Claude aliases and shortcuts quietly
[ -f ~/.claude/aliases.sh ] && source ~/.claude/aliases.sh 2>/dev/null
[ -f ~/.claude/admin_shortcuts.sh ] && source ~/.claude/admin_shortcuts.sh 2>/dev/null
[ -f "/Users/MAC/.claude/cks-environment.sh" ] && source "/Users/MAC/.claude/cks-environment.sh" 2>/dev/null

# Simple prompt logging functions (no export in zsh)
prompt_backtrack() {
    local search="${1}"
    local last="${2:-20}"
    python3 "$PROMPT_LOGGER_PATH" backtrack --search "$search" --last "$last"
}

prompt_analyze() {
    python3 "$PROMPT_LOGGER_PATH" analyze
}

prompt_replay() {
    local session="${1}"
    python3 "$PROMPT_LOGGER_PATH" replay --session "$session"
}

# Quick aliases
alias ccl='python3 "$ENHANCED_LOGGER_PATH" log'
alias ccmon='python3 "$HOME/.claude/cc_attribution_monitor.py"'
alias ccsum='python3 "$ENHANCED_LOGGER_PATH" summary'
alias pback='prompt_backtrack'
alias panalyze='prompt_analyze'
alias preplay='prompt_replay'
alias plast='prompt_backtrack "" 5'

# Database shortcuts
alias db_query='sqlite3 $UNIFIED_DB_PATH'
alias db_stats='echo "SELECT name FROM sqlite_master WHERE type=\"table\";" | sqlite3 $UNIFIED_DB_PATH'
alias db_operations='echo "SELECT COUNT(*) as total, tool_used FROM operations GROUP BY tool_used;" | sqlite3 $UNIFIED_DB_PATH'

# Auto-log command prompts (if interactive)
if [[ $- == *i* ]]; then
    PROMPT_COMMAND='python3 "$PROMPT_LOGGER_PATH" log "command" "$(history 1 2>/dev/null)" 2>/dev/null'
fi
# CKS/CLS Autonomous System (Auto-start)
# Moved to Claude Code hooks - not needed in terminal startup
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'

# CKS/CLS Quick Training Command
alias train='/Users/MAC/.claude/train'

# CKS/CLS Complete Automation
# Moved to Claude Code hooks - not needed in terminal startup
alias cks='/Users/MAC/.claude/cks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
export CC_HOOKS_PATH='/Users/MAC/.claude/hooks'
alias voice="~/.claude/voice-input.sh"
alias v="~/.claude/voice-input.sh"
export CLAUDE_CODE_MAX_OUTPUT_TOKENS=128000
export PATH="$HOME/.local/bin:$PATH"
alias secrets="/Users/MAC/.claude/secrets/manage-secrets.sh"
export PATH="$HOME/Documents/projects/stolution/ccm-v2/bin:$PATH"
alias rcc="ssh -t stolution \"export CC_INSTANCE_NAME=ROOT-SERVER && cd /home/s903/stolution && claude\""

# OpenClaw Completion
source "/Users/MAC/.openclaw/completions/openclaw.zsh"

alias claude-mem='bun "/Users/MAC/.claude/everything-claude-code/scripts/worker-service.cjs"'

# direnv hook (per-project .envrc auto-activation)
eval "$(/opt/homebrew/bin/direnv hook zsh)"
