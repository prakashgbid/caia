# BL-EXEC-VALIDATION-FAILED

**Filed:** 2026-04-21T05:15:00Z
**Severity:** high
**Status:** open

## Summary

Validation drain (limit=10) failed with P/N=0% (0 of 21 tasks reached done state).

## Failure Pattern

Stage where failures clustered: **completion-hook / API layer**

Dispatcher worked correctly (21 workers spawned, claude -p ran, workers exited).
Completion hook failed on every task with: `Task <id> not found — skipping completion hook`

## Root Causes

1. **Missing API endpoints** — `GET /tasks/:id` and `PATCH /tasks/:id` not registered in
   `src/api/routes/executor.ts`. The completion hook calls these to fetch + update task state.
   Result: 21 tasks stuck in `status=running` in DB.

2. **Drain counter bug** — Daemon tracked net change in `currentMonitored.length`
   (workers spawned minus workers finished that tick) instead of cumulative total dispatched.
   Result: Dispatched 21 tasks instead of the intended 10.

## Evidence

```
[executor:daemon] Spawned task tsk_snik0ZrR (PID 89707)
[executor:daemon] Worker done: task=tsk_snik0ZrR outcome=done
[executor:hook] Task tsk_snik0ZrR not found — skipping completion hook
```

Full log: /tmp/executor-drain-10.log (21 spawned, 18 done, 18 "not found" errors)

## DB State Post-Drain

- running: 21 (stuck — completion hook couldn't update)
- queued: 7 (remaining)
- completed_24h: 0

## Resolution Plan

1. Add `GET /tasks/:id` and `PATCH /tasks/:id` to executor.ts
2. Fix drain counter (use accumulator not net delta)
3. Reset 21 stuck tasks to queued
4. Re-run validation drain

## Next Action

User review requested before proceeding to 24/7 launchd install.
Fix is underway in same session.
