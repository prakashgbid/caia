# BL-GA4-MEASUREMENT-IDS

**Filed:** 2026-04-21
**Blocker type:** External service — requires browser login
**Affects:** poker-zeno, roulette-community

## Problem

Both sites have placeholder GA4 Measurement IDs in their `.env.local` files:
- `/Users/MAC/Documents/projects/poker-zeno/.env.local` — `NEXT_PUBLIC_GA4_MEASUREMENT_ID` = placeholder
- `/Users/MAC/Documents/projects/roulette-community/.env.local` — `NEXT_PUBLIC_GA4_MEASUREMENT_ID` = placeholder

No GA4 credentials are stored in the vault (`~/.vault/`, `~/.stolution-vault/`).

## Steps to resolve

1. Go to https://analytics.google.com
2. Sign in with prakashmailid@gmail.com
3. For **pokerzeno.com**:
   - Admin → Create Property → Name: "PokerZeno" → Select web stream → URL: pokerzeno.com
   - Copy Measurement ID (format: `G-XXXXXXXXXX`)
   - Set in `/Users/MAC/Documents/projects/poker-zeno/.env.local`:
     `NEXT_PUBLIC_GA4_MEASUREMENT_ID=G-XXXXXXXXXX`
4. For **roulettecommunity.com**:
   - Admin → Create Property → Name: "RouletteCommunity" → web stream → URL: roulettecommunity.com
   - Copy Measurement ID
   - Set in `/Users/MAC/Documents/projects/roulette-community/.env.local`:
     `NEXT_PUBLIC_GA4_MEASUREMENT_ID=G-XXXXXXXXXX`
5. Rebuild and redeploy both sites.

## Why not automated

GA4 property creation requires OAuth login to Google Analytics. No Google service account credentials are in the vault.
