# BL-GA-ACCOUNT-BINDING — Grant Service Account Access to GA4 Account

**Status:** BLOCKING  
**Filed:** 2026-04-21  
**Unblocks:** GA4 property creation (requires BL-GA-API-ENABLE to be resolved first)

## What's blocked

Even after the Analytics Admin API is enabled, the service account must be granted 
**Administrator** access to GA4 Account `238524267` before it can create properties, 
data streams, or read account metadata.

Google requires this grant to come from an existing Admin via the GA4 UI — it cannot 
be automated via the API.

## Service account to grant

```
stolution-backup-automation@planar-cycle-297510.iam.gserviceaccount.com
```

## User action required (< 3 minutes)

1. Open: https://analytics.google.com/analytics/web/#/a238524267/admin
2. In the left sidebar: **Account** → **Account Access Management**
3. Click **+** (top-right)
4. Paste the service account email: `stolution-backup-automation@planar-cycle-297510.iam.gserviceaccount.com`
5. Set role: **Administrator**
6. Click **Add**

## After granting access

Reply **"account bound"** to resume the GA4 setup task.  
At that point the script will:
- Create 4 GA4 properties (PokerZeno, Roulette Community, Edison Cricket, Stolution)
- Create web data streams and retrieve Measurement IDs
- Wire IDs into .env files and redeploy the two live sites
