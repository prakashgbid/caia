# BL-FRAMEWORK-TESTS-DEFERRED

**Filed**: 2026-04-20  
**Severity**: Medium  
**Status**: Open

## Problem

Monorepo test suite (`pnpm -r test` or equivalent) has caused session hangs on 3 consecutive respawn attempts. Tests are NOT being run as part of scaffold validation to avoid blocking progress.

## Symptoms

- Long-running test commands hang indefinitely in Claude Code sessions
- Previous respawns (attempts 1, 2, 3) stalled specifically on cross-repo test execution
- No individual repo test failures confirmed — the hang appears to be at the orchestration level

## Scope

Repos with tests that need validation:
- `poker-zeno/` — vitest + playwright behavior tests
- `roulette-community/` — vitest + playwright behavior tests
- `pokerzeno-plugins/` — package-level unit tests
- `framework/bin/new-site.sh` — integration test (actual scaffold, not dry-run)

## Next Steps

1. Run tests in individual repos (not cross-repo) to isolate which hangs
2. Check if `npm run test` in `poker-zeno/` completes within 60s
3. Check if playwright needs a headed browser (may require display server)
4. Consider adding a `--timeout` flag to CI test commands
5. Once isolated, remove this blocker

## Non-blocking

The framework scaffold (framework/, site-template/, new-site.sh dry-run) is complete and working. This blocker only affects test suite validation.
