# BL-PIXABAY-API-KEY

**Filed:** 2026-04-21
**Blocker type:** Missing credential — not in vault
**Affects:** @pokerzeno/image-provider plugin

## Problem

The image-provider plugin at `/Users/MAC/Documents/projects/pokerzeno-plugins/packages/image-provider/.env` has `PIXABAY_API_KEY` listed as a TODO placeholder. No Pixabay key is stored in:
- `~/.vault/` (remote stolution server)
- `~/.stolution-vault/` (remote)
- Any local env files

Note: Pexels and Unsplash keys ARE present in the vault and the plugin `.env`.

## Steps to resolve

1. Go to https://pixabay.com/api/docs/
2. Sign up / log in
3. Copy the API key from your profile
4. Add to `/Users/MAC/Documents/projects/pokerzeno-plugins/packages/image-provider/.env`:
   `PIXABAY_API_KEY=your_key_here`
5. Also store in vault: `ssh stolution 'echo "PIXABAY_API_KEY=xxx" >> ~/.vault/image-provider-pixabay.env && chmod 600 ~/.vault/image-provider-pixabay.env'`

## Notes

- Pixabay is optional (Pexels + Unsplash are already wired). The plugin skips missing sources with a warning.
- Free plan: 100 requests/minute, commercial use OK.
