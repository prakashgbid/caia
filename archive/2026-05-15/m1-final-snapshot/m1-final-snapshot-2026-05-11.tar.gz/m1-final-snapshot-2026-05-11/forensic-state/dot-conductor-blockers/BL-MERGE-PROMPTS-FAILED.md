# BL-MERGE-PROMPTS-FAILED

**Filed:** 2026-04-21T14:11:33Z  
**Branch:** claude/friendly-northcutt-1ab7fb  
**Gate failed:** gate:coverage (delta check on changed files)  
**Action taken:** Merge rolled back to master@81b3ecf

## Failure Detail

Coverage gate (`scripts/check-coverage-delta.ts`) checks all TypeScript files changed vs HEAD~1.  
Threshold: 80% on both lines and functions.

3 files below threshold after merge:

| File | Lines | Functions |
|------|-------|-----------|
| src/api/app.ts | 94% | **75%** |
| src/db/schema.ts | **79%** | **63%** |
| src/prompts/manager.ts | 83% | **60%** |

## Required Fix

The `claude/friendly-northcutt-1ab7fb` branch must add tests covering:
- `src/api/app.ts` functions (currently 3/4 covered — need to find and test the uncovered function)
- `src/db/schema.ts` — schema helper functions likely untested (63% function coverage)
- `src/prompts/manager.ts` — 60% function coverage; `tests/api/prompts.test.ts` exists but doesn't exercise enough of the manager's methods

All 3 files must reach ≥80% on both lines and functions before re-attempting the merge.

## Notes

- Tests themselves all passed (349/349 green)
- Build passed (TypeScript clean)
- Lint gate is a pre-existing failure (no eslint.config — not blocking, pre-dates this branch)
- Migration files 0006_completeness.sql and 0007_executor.sql were different between local untracked and branch — branch versions used (backed up at /tmp/local_0006_completeness.sql and /tmp/local_0007_executor.sql)
