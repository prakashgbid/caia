# BL-GA-API-ENABLE — Enable Analytics Admin API on GCP Project

**Status:** BLOCKING  
**Filed:** 2026-04-21  
**Unblocks:** GA4 property creation (BL-GA-ACCOUNT-BINDING must also be resolved)

## What's blocked

The service account `stolution-backup-automation@planar-cycle-297510.iam.gserviceaccount.com` 
cannot create GA4 properties because the Analytics Admin API is **disabled** on GCP project 
`planar-cycle-297510` (numeric ID: `297878136694`).

The service account has valid credentials and correct OAuth scopes — it just needs the API enabled.

## User action required (< 2 minutes)

**Option A — GCP Console (easiest):**

1. Open: https://console.cloud.google.com/apis/library/analyticsadmin.googleapis.com?project=planar-cycle-297510
2. Click **Enable**
3. Wait ~60 seconds for propagation

**Option B — gcloud CLI (if you have it locally):**
```bash
gcloud auth login
gcloud services enable analyticsadmin.googleapis.com --project=planar-cycle-297510
```

## After enabling

Reply **"api enabled"** to resume the GA4 setup task.  
You will also need to resolve BL-GA-ACCOUNT-BINDING before properties can be created.
