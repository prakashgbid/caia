# Live-wizard smoke — CD ZIP fixture

Minimal valid CD ZIP for Step 6 (Design Upload). Mirrors the shape of
`packages/design-ingest-adapter-cd-zip/tests/fixtures/minimal/`.
