export default function ShopPage() {
  return (
    <main data-route="/shop">
      <h1>Browse Studios</h1>
    </main>
  );
}
