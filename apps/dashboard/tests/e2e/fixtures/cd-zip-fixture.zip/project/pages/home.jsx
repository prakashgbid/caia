// pages/home.jsx — Smoke fixture for live-wizard Step 6 (Design).
export default function HomePage() {
  return (
    <main className="pt-band-paper" data-route="/">
      <section id="hero">
        <h1>Handmade Ceramics, Curated</h1>
        <a href="/shop" data-go="/shop">Shop the studio</a>
      </section>
    </main>
  );
}
